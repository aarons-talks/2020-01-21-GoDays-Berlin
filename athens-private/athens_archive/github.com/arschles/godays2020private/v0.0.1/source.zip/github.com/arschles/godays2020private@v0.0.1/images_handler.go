package godays2020private

import (
	"github.com/gin-gonic/gin"
	"github.com/gobuffalo/plush"
)

// ImagesHandler takes the current URL,
// a string representation of a plush template, and a slice of
// image URLs.
//
// It then picks a random image URL and renders the template with the
// 'imgSrc' template variable set to the random image URL and 'curURL'
// set to the value of curURL
func ImagesHandler(curURL, template string, images []string) func(*gin.Context) {
	return func(c *gin.Context) {
		randImg := randStr(images)
		ctx := plush.NewContext()
		ctx.Set("imgSrc", randImg)
		ctx.Set("curURL", curURL)
		rendered, err := plush.Render(template, ctx)
		if err != nil {
			c.String(500, "Error rendering template: %s", err)
			return
		}
		renderHTML(c, rendered)
	}

}
