package godays2020private

import "testing"

func TestRandStr(t *testing.T) {
	slc := []string{"1", "2"}
	ret := randStr(slc)
	if ret != slc[0] && ret != slc[1] {
		t.Fatal("randStr didn't return the right thing!")
	}
}
